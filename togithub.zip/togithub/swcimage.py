import os

import pandas as pd
from matplotlib import pyplot as plt


import pandas as pd

def readSWC(swc_path, mode='simple'):  # pandas DataFrame
    n_skip = 0
    with open(swc_path, "r") as f:
        for line in f.readlines():
            line = line.strip()
            if line.startswith("#"):
                n_skip += 1
            else:
                break

    names = ["##n", "type", "x", "y", "z", "r", "parent"]
    used_cols = [0, 1, 2, 3, 4, 5, 6]

    df = pd.read_csv(swc_path, index_col=0, skiprows=n_skip, sep=" ",
                     usecols=used_cols,
                     names=names)

    # 只保留df的前一半内容
    # 检查 ##n 列中是否有两个 1
    indices = df.index[df["parent"] == -1].tolist()
    if len(indices) == 2:
        # 如果有两个 1，则只保留第二个 1 之前的内容
        df = df.iloc[:len(df) // 2]

    return df


def get_degree(tswc):   # Degree of node: the number of nodes connected to it
    tswc['degree'] = tswc['parent'].isin(tswc.index).astype('int')
    # print(tswc['degree'])
    print(tswc.index)
    print(tswc.index.duplicated())  # 查看哪些索引是重复的
    print(tswc.index[tswc.index.duplicated()])  # 打印出重复的索引值

    n_child = tswc.parent.value_counts()
    n_child = n_child[n_child.index.isin(tswc.index)]
    tswc.loc[n_child.index, 'degree'] = tswc.loc[n_child.index, 'degree'] + n_child
    return tswc

def get_rid(swc):
    '''
    Find root node.
    '''
    rnode=swc[((swc['parent']<0) & (swc['type']<=1))]
    if rnode.shape[0]<1:
        return -1
    return rnode.index[0]

def get_keypoint(swc, rid=None):  # keypoint: degree ≠ 2 (branches & tips)
    if rid is None:
        rid = get_rid(swc)
    # print(swc.shape)
    swc=get_degree(swc)
    idlist = swc[((swc.degree!=2) | (swc.index==rid))].index.tolist()
    return idlist

def swc2branches(swc):
    '''
    reture branch list of a swc
    '''
    keyids=get_keypoint(swc)
    branches=[]
    for key in keyids:
        if (swc.loc[key,'parent']<0) | (swc.loc[key,'type']<=1):
            continue
        branch=[]
        branch.append(key)
        pkey=swc.loc[key,'parent']
        while True:
            branch.append(pkey)
            if pkey in keyids:
                break
            key=pkey
            pkey=swc.loc[key,'parent']
        branches.append(branch)
    return branches

def show_neuron_swc(swc_path: str):
    """
    Displays a neuron structure from an SWC file.

    Args:
        swc_path (str): The path to the SWC file.

    Returns:
        matplotlib.axes.Axes: The axes containing the plot.
    """
    # Read the SWC file
    swc = readSWC(swc_path)

    # Get the branches of the neuron structure
    branches = swc2branches(swc)

    # Create a new figure and axes
    _, ax = plt.subplots(figsize=(5.12, 5.12))

    # Plot the neuron structure
    colors = ['white', 'black', 'red', 'blue', 'magenta', 'green']
    for branch in branches:
        br_color = colors[int(swc.loc[branch[0], 'type']) % len(colors)]
        x_coords = [swc.loc[node, 'x'] for node in branch]
        y_coords = [swc.loc[node, 'y'] for node in branch]
        ax.plot(x_coords, y_coords, color=br_color)

    # Set equal aspect ratio and remove axes
    ax.set_aspect('equal')
    ax.axis('off')
    res=swc_path.replace(".swc",".jpg")
    plt.savefig(res)

    # # 调用vaa3d显示SWC
    # vaa3d_exe = 'C://Users//kaixiang//Desktop//Vaa3D-x.1.1.2_Windows_64bit//Vaa3D-x.exe'
    # subprocess.Popen([vaa3d_exe, swc_path])

    return res



def get_swcimage():
   # globalpath=r"C:\Users\86132\Desktop\SWC文件下的组化匹配\9561-9579\09561_P041_T01_-_S014_-_TL.R_R0919_OMZ_20230713_YW_somadefined.ano.swc"
    globalpath="/mnt/nfs/hndb/SWC/auto1.4/00000_00999/00000_00099/00002_P001_T01-S001_MFG_R0460_WY-20220415_XJ.swc"
    swcimage=show_neuron_swc(globalpath)

    # # 定义数据库URL
    # SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:root@localhost/human_neuron"
    #
    # # 创建数据库引擎
    # engineg = create_engine(SQLALCHEMY_DATABASE_URLg)
    #
    # # 创建MetaData对象
    # metadatag = MetaData()
    #
    # # 反射目标表
    # tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)
    #
    # # 创建会话
    # Session = sessionmaker(bind=engineg)
    # session = Session()
    # stmt = (
    #     update(tracking_table)
    #         .where(tracking_table.c['Cell ID'] == swcimagename)  # 这里假设表中有一个主键id列
    #         .values(swc_image=swcimage)
    # )
    # session.execute(stmt)
    # # 提交事务
    # session.commit()
    #
    # # 关闭会话
    # session.close()
    #
get_swcimage()
'''***************************************************SWC可视化结束***************************************************'''
