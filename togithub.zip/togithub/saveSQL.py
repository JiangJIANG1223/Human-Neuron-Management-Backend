import subprocess
import datetime
import os

# 获取当前日期
today = datetime.datetime.now()
date_str = today.strftime("%m%d")  # 格式化日期为 MMDD

# 数据库配置信息
source_db = "human_neuron"
user = "root"
password = "hneuronbyseu123"  # 请确保妥善安全存储密码
host = "localhost"  # 数据库主机地址

# 导出 human_neuron 数据库的 SQL 文件保存路径
dump_file = f"/mnt/nfs/sql_save/human_neuron_{date_str}.sql"

# 使用 mysqldump 导出数据库
try:
        # 打开文件以写入并指定编码
        with open(dump_file, 'w', encoding='utf-8') as output_file:
                subprocess.run([
                        "mysqldump",
                        "--default-character-set=utf8",  # 指定字符集为 UTF-8
                        "-u", user,
                        "-p" + password,  # 密码在这里与选项合并在一起
                        "-h", host,
                        source_db
                ], stdout=output_file, check=True)  # stdout 将结果输出到指定文件

        print(f"成功导出数据库 {source_db} 到文件 {dump_file}")

except subprocess.CalledProcessError as e:
        print(f"导出数据库失败: {e}")
except Exception as e:
        print(f"发生错误: {e}")
