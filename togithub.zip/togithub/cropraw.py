import os
import cv2
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image
from sqlalchemy import create_engine, select, Table, MetaData, update
from sqlalchemy.orm import sessionmaker
from v3dpy.loaders import Raw, PBD

def getMultiSoma():
    # 定义数据库URL
    SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"
    # 创建数据库引擎
    engineg = create_engine(SQLALCHEMY_DATABASE_URLg)
    # 创建MetaData对象
    metadatag = MetaData()
    # 反射目标表
    tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)

    re=[] # 最后返回的结果 # 每个元素分别对应，Result: [CellID、rawID、MIP、x、y、z]

    with engineg.connect() as connection:
        # 使用直接列引用来查询第二列
        query = select(tracking_table.c['Image Cell ID'])  # 确保使用正确的列名
        result = connection.execute(query)

        queryCell = select(tracking_table.c['Cell ID'])  # 确保使用正确的列名
        resultCell = connection.execute(queryCell)

        queryMIP = select(tracking_table.c['image_file'])  # 确保使用正确的列名
        resultMIP = connection.execute(queryMIP)

        queryx = select(tracking_table.c['soma_x'])  # 确保使用正确的列名
        resultx = connection.execute(queryx)

        queryy = select(tracking_table.c['soma_y'])  # 确保使用正确的列名
        resulty = connection.execute(queryy)

        queryz = select(tracking_table.c['soma_z'])  # 确保使用正确的列名
        resultz = connection.execute(queryz)

        # 提取结果到列表中
        second_column_data = [row[0] for row in result]
        xc=[row[0] for row in resultx]
        yc=[row[0] for row in resulty]
        zc=[row[0] for row in resultz]
        CellID=[row[0] for row in resultCell]
        MIP=[row[0] for row in resultMIP]

    # 提取不为空的数据和对应的下标
    non_empty_data_with_indices = [(index, rawID) for index, rawID in enumerate(second_column_data)
                                   if rawID != '-' and rawID >'14402'] # 先过滤没有Image Cell ID的
    # 输出结果
    for index, rawID in non_empty_data_with_indices:
        # 再过滤有Image Cell ID但没有soma坐标的
        if( xc[index]=='-' or yc[index]=='-' or zc[index]=='-'):
            continue

        re.append([CellID[index],rawID,MIP[index],xc[index],yc[index],zc[index]])
       # print(f"Index: {index}, raw: {rawID}, Cell: {CellID[index]}", xc[index],yc[index],zc[index],type(zc[index]))
   # print('re',re)
    return re  #每个元素是Result: [CellID、rawID、MIP、x、y、z]


def find_storage_path(base_folder, filename):
    file_number = int(filename.split('_')[0])  # 例如 "00028.txt" -> 28

    # 遍历基础文件夹，寻找合适的外层文件夹
    for outer_folder in os.listdir(base_folder):
        outer_folder_path = os.path.join(base_folder, outer_folder)
        if os.path.isdir(outer_folder_path):
            # 获取外层文件夹的范围
            outer_start, outer_end = map(int, outer_folder.split('_'))
            if outer_start <= file_number <= outer_end:
                # 遍历找到的外层文件夹，寻找合适的内层文件夹
                for inner_folder in os.listdir(outer_folder_path):
                    # print(outer_folder_path.split("\\")[-1])
                    f1=outer_folder_path.split("\\")[-1]
                    inner_folder_path = os.path.join(outer_folder_path, inner_folder)
                    if os.path.isdir(inner_folder_path):
                        # 获取内层文件夹的范围
                        inner_start, inner_end = map(int, inner_folder.split('_'))
                        if inner_start <= file_number <= inner_end:
                            f2=inner_folder_path.split("\\")[-1]
                            # 构造最终路径
                            # return os.path.join(inner_folder_path, filename)
                            return f1+"/"+f2

    return None  # 如果没有找到合适的文件夹


def cropmip(CellID,rawID,x,y,z):
    print("key Info",CellID,rawID,x,y,z)
    mipbasepath="/mnt/nfs/hndb/"

    result_path=find_storage_path(mipbasepath+"V3DRAW_8bit", rawID)
    parts = result_path.split('//')
    result_path = parts[1].split('/')[-2] + '/' + parts[1].split('/')[-1]

    print("1result path", result_path) #输出的是 10000_10999/10000_10099这种


    result_path1=find_storage_path(mipbasepath+"MIP_Downsample", CellID)
    parts = result_path1.split('//')
    result_path1 = parts[1].split('/')[-2] + '/' + parts[1].split('/')[-1]

    print("2result path", result_path1) #输出的是 10000_10999/10000_10099这种

    rawfile = mipbasepath+"V3DRAW_8bit/"+result_path
    # 遍历文件夹
    for root, dirs, files in os.walk(rawfile):
        for file in files:
            if file.split("_")[0] == rawID:
                # 返回该文件的绝对路径
                rawfile=os.path.abspath(os.path.join(root, file)).replace("\\","/")
                break
    print("---",rawfile)
    raw = Raw()
    img = raw.load(rawfile)  #读取的shape顺序是z，y，x
    xs,ys,zs=img[0].shape[2],img[0].shape[1],img[0].shape[0]

    xp = 256
    xn = 256
    yp = 256
    yn = 256

    x_start = max(x - xn, 0)
    x_end = min(x + xp, xs)
    y_start = max(y - yn, 0)
    y_end = min(y + yp, ys)

    # 切片操作
    A_sliced = img[0][0:zs, y_start:y_end, x_start:x_end]
    print('第一步：抠图')


    newrawfile_dir=os.path.dirname(rawfile)
    newrawfile_name=os.path.basename(rawfile)
    print("切片后的数组形状:", A_sliced.shape,A_sliced[0].shape)
    max_values = np.max(A_sliced, axis=0)  # shape will be (512, 512)
    # 创建一个 PIL Image 对象
    image = Image.fromarray(max_values)
        # 进行水平方向的镜像
    image = image.transpose(Image.FLIP_LEFT_RIGHT)
    # 顺时针旋转180度
    image = image.rotate(-180)  # 负值表示顺时针旋转

    # 保存为 TIFF 格式
    outImage=os.path.join(mipbasepath+"MIP_Downsample/"+result_path1,CellID+'_Crop.tif').replace("\\", "/")
    print(outImage)

    # 提取所需部分
    db_part = outImage.split("/mnt/nfs/hndb/")[-1]
    print(db_part)
    image.save(outImage)

    '''****************************更新后的MIP入库*********************************'''
    # 定义数据库URL
    SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"
    # 创建数据库引擎
    engineg = create_engine(SQLALCHEMY_DATABASE_URLg)
    # 创建MetaData对象
    metadatag = MetaData()
    # 反射目标表
    tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)
    # 创建会话
    Session = sessionmaker(bind=engineg)
    session = Session()

    stmt = (
        update(tracking_table)
            .where(tracking_table.c['Cell ID'] == CellID)  # 这里假设表中有一个主键id列
            .values(cropMIP=tracking_table.c.image_file)
    )
    session.execute(stmt)

    stmt1 = (
        update(tracking_table)
        .where(tracking_table.c['Cell ID'] == CellID)  # 这里假设表中有一个主键id列
        .values(image_file=db_part)
    )
    session.execute(stmt1)
    # 提交事务
    session.commit()
    # 关闭会话
    session.close()
    '''****************************更新后的MIP入库*********************************'''

totalMUltiSoma=getMultiSoma()
for item in totalMUltiSoma:
    cropmip(item[0],item[1],int(item[3]),int(item[4]),int(item[5]))
    print('-------------------')



