from sqlalchemy import create_engine, select, Table, MetaData, and_

# 定义数据库URL
SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"

# 创建数据库引擎
engineg = create_engine(SQLALCHEMY_DATABASE_URLg)

# 创建MetaData对象
metadatag = MetaData()

# 反射目标表
tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)

# 创建查询
query = select(tracking_table).where(tracking_table.c['Cell ID'] == 14567)  # 假设列名为 CellID

# 执行查询并输出结果
with engineg.connect() as connection:
    result = connection.execute(query)
    for row in result:
        print(row)

