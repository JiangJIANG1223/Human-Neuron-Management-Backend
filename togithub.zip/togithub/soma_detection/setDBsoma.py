from sqlalchemy import create_engine, select, Table, MetaData, update
from sqlalchemy.orm import sessionmaker
import os
import sys
import subprocess
import numpy as np
import tifffile
import cc3d

def compute_centroid(mask):
    # 使用 cc3d 对3D mask进行连通区域标记
    labels = cc3d.connected_components(mask)  # 默认情况下, cc3d 会返回一个与 mask 同形状的标记数组

    # 初始化最大连通块的体积为0和其标签
    max_volume = 0
    max_label = 0

    # 找出最大的连通块
    for label in np.unique(labels):
        if label == 0:  # 跳过背景
            continue
        volume = (labels == label).sum()
        if volume > max_volume:
            max_volume = volume
            max_label = label

    # 如果没有找到连通块，则返回None
    if max_label == 0:
        return None

    # 计算最大连通块的重心
    coords = np.argwhere(labels == max_label)
    centroid = coords.mean(axis=0)

    return tuple(centroid)

def simple_get_soma(img_path, temp_path=r"/soma_detection/temp", v3d_path=r"/vaa3d/Vaa3D-x.1.1.4_Ubuntu/Vaa3D-x"):
    file_name = os.path.basename(img_path)
    # print(file_name)
    in_tmp = os.path.join(temp_path, file_name + 'temp.tif').replace("\\","/")

    # 读取图像
    img = tifffile.imread(img_path)
    print(img)

    img = (img - np.min(img)) / (np.max(img) - np.min(img)) * 255
    tifffile.imwrite(in_tmp, img.astype(np.uint8))
    out_tmp = in_tmp.replace('.tif', '_gsdt.tif')
    with open(out_tmp, 'w') as file:
        tifffile.imwrite(out_tmp, img.astype(np.uint8))

    if (sys.platform == "linux"):
        cmd_str = f'xvfb-run -a -s "-screen 0 640x480x16" {v3d_path} -x gsdt -f gsdt -i {in_tmp} -o {out_tmp} -p 0 1 0 1.5'
        cmd_str = cmd_str.replace('(', '\(').replace(')', '\)')
        # print(cmd_str)
        subprocess.run(cmd_str, stdout=subprocess.DEVNULL, shell=True)
    else:
        cmd = f'{v3d_path} /x gsdt /f gsdt /i {in_tmp} /o {out_tmp} /p 0 1 0 1.5'
        print(cmd)
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    if(not os.path.exists(out_tmp)):
        return 'hsd'
    gsdt = tifffile.imread(out_tmp).astype(np.uint8)
    gsdt = np.flip(gsdt, axis=1)

    max_gsdt = np.max(gsdt)
    gsdt[gsdt <= max_gsdt * 0.95] = 0
    gsdt[gsdt > max_gsdt * 0.95] = 1

    centroid = compute_centroid(gsdt)
    # print(",,")

    if (os.path.exists(out_tmp)): os.remove(out_tmp)
    if (os.path.exists(in_tmp)): os.remove(in_tmp)
    del out_tmp, in_tmp

    return centroid




# 定义数据库URL
SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"
# 创建数据库引擎
engineg = create_engine(SQLALCHEMY_DATABASE_URLg)
# 创建MetaData对象
metadatag = MetaData()
# 反射目标表
tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)
print(tracking_table.columns.keys()) # 查询所有列的名称
# 查询第二列（假设你的第二列名称为 'Cell ID'，请根据实际的列名进行替换）
re=[]
with engineg.connect() as connection:
    # 使用直接列引用来查询第二列
    query = select(tracking_table.c['Image Cell ID'])  # 确保使用正确的列名
    result = connection.execute(query)

    queryCell = select(tracking_table.c['Cell ID'])  # 确保使用正确的列名
    resultCell = connection.execute(queryCell)

    querySWC = select(tracking_table.c['swc_auto14'])  # 确保使用正确的列名
    resultSWC = connection.execute(querySWC)

    queryMIP = select(tracking_table.c['image_file'])  # 确保使用正确的列名
    resultMIP = connection.execute(queryMIP)




# 提取结果到列表中
    second_column_data = [row[0] for row in result]
    CellID=[row[0] for row in resultCell]
    SWC=[row[0] for row in resultSWC]
    MIP=[row[0] for row in resultMIP]

# 提取不为空的数据和对应的下标
non_empty_data_with_indices = [(index, rawID) for index, rawID in enumerate(second_column_data) if rawID == '-']
# 输出结果
Session = sessionmaker(bind=engineg)
session = Session()

swcpath="/mnt/nfs/hndb"

for index, rawID in non_empty_data_with_indices:
   # print(f"Index: {index}, raw: {rawID}, Cell: {CellID[index]}, SWC: {SWC[index]}, MIP: {MIP[index]}")
    if (SWC[index]==None or SWC[index]=='-'):
        p=swcpath+"/"+MIP[index]
        print(p)
        coor=simple_get_soma(p)
        print(coor[0],coor[1])
        print('___________________________________________________________________')
        stmt = (
            update(tracking_table)
                .where(tracking_table.c['Cell ID'] == CellID[index])  # 这里假设表中有一个主键id列
                .values(soma_x=coor[0], soma_y=coor[1])  # 将多个字段的值放在一个字典中
        )
        session.execute(stmt)

# 提交事务
session.commit()

# 关闭会话
session.close()
