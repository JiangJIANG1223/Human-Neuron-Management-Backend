import ast
import os
import cv2
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image
from sqlalchemy import create_engine, select, Table, MetaData, update
from sqlalchemy.orm import sessionmaker

'''****************************更新后的MIP入库*********************************'''
# 定义数据库URL
SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"
# 创建数据库引擎
engineg = create_engine(SQLALCHEMY_DATABASE_URLg)
# 创建MetaData对象
metadatag = MetaData()
# 反射目标表
tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)
# 创建会话
Session = sessionmaker(bind=engineg)
session = Session()

'''****************************更新后的MIP入库*********************************'''




# 初始化一个空列表
re = []
# 打开文件并读取每一行
with open('DB_MIP_NoCrop.txt', 'r') as file:
    for line in file:
        # 去除行尾的换行符，并将其解析为列表
        try:
            # 使用 ast.literal_eval 将字符串内容转换为列表
            parsed_line = ast.literal_eval(line.strip())
            re.append(parsed_line)
        except (SyntaxError, ValueError) as e:
            print(f"无法解析这一行: {line.strip()}，错误: {e}")



for item in re:
    print(item[0])
    print(item[2])
    print('--------------------------------------------')
    stmt = (
        update(tracking_table)
        .where(tracking_table.c['Cell ID'] == item[0])  # 这里假设表中有一个主键id列
        .values(image_file=item[2])
    )
    session.execute(stmt)
# 提交事务
session.commit()
# 关闭会话
session.close()
