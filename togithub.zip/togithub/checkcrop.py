from sqlalchemy import create_engine, MetaData, Table, select  

# 定义数据库URL  
SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"  

# 创建数据库引擎  
engineg = create_engine(SQLALCHEMY_DATABASE_URLg)  

# 创建MetaData对象  
metadatag = MetaData()  

# 反射目标表  
tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)  

# 创建查询  
query = select(  
    tracking_table.c['Image Cell ID'],  
    tracking_table.c.soma_x,  
    tracking_table.c.soma_y,  
    tracking_table.c.soma_z  
               ).where(tracking_table.c['Cell ID'] == 16637)  

# 执行查询  
with engineg.connect() as connection:  
    result = connection.execute(query)  
    
    # 获取查询结果  
    for row in result:  
        print(f"Image Cell ID: {row[0]}, soma_x: {type(row.soma_x)}, soma_y: {row.soma_y}, soma_z: {row.soma_z}")
