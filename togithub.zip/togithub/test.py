import os
import subprocess

neuronImage="/human_brain_env/00029_p_P041_T01_-_S014_-_TL.R_R0919_OMZ_20230713_YW.v3draw"
outImage="/human_brain_env/233.v3draw"
MIPimage="/human_brain_env/233.mip"
pbdimage="/human_brain_env/233.v3dpbd"
#command = r"/vaa3d/Vaa3D-x.1.1.4_Ubuntu/Vaa3D-x " \
#          r"-x /vaa3d/Vaa3D-x.1.1.4_Ubuntu/plugins/data_type/Convert_8_16_32_bits_data/libdatatypeconvert.so " \
#          r"-f dtc -i {} -o {} -p {}".format(neuronImage,outImage,1)
cmd = f'xvfb-run -a -s "-screen 0 640x480x16" "/vaa3d/Vaa3D-x.1.1.4Ubuntu/Vaa3D-x" -x datatypeconvert -f dtc -i {neuronImage} -o {outImage} -p 1'
cmd1 = f'xvfb-run -a -s "-screen 0 640x480x16" "/vaa3d/Vaa3D-x.1.1.4Ubuntu/Vaa3D-x" -x mipZSlices -f mip_zslices -i {neuronImage} -o {MIPimage} -p 1:1:e'
cmd2 = f'xvfb-run -a -s "-screen 0 640x480x16" "/vaa3d/Vaa3D-x.1.1.4Ubuntu/Vaa3D-x" -x convert_file_format -f convert_format -i {neuronImage} -o {pbdimage}'


# `cmd = process_path(cmd)
# subprocess.run(cmd, stdout=subprocess.DEVNULL, shell=True)

os.system(cmd2)








