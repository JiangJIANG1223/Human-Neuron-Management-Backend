from sqlalchemy import create_engine, MetaData, Table, update
from sqlalchemy.orm import sessionmaker
import csv

# 定义数据库URL
SQLALCHEMY_DATABASE_URL = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"

# 创建数据库引擎
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# 创建MetaData对象
metadata = MetaData()

# 反射目标表
tracking_table = Table('human_singlecell_trackingtable_20240712', metadata, autoload_with=engine)

# 创建Session
Session = sessionmaker(bind=engine)
session = Session()

# 定义CSV文件的路径
csv_file_path = r"HBN_markers.csv"  # 请替换为你的CSV文件路径

# 读取CSV文件并更新数据库
with open(csv_file_path, mode='r', encoding='utf-8') as file:
    csv_reader = csv.reader(file)
    # next(csv_reader)  # 如果CSV文件有表头，可以跳过表头
    for row in csv_reader:
        cell_id = row[0]
        soma_x = row[1].split('.')[0]
        soma_y = row[2].split('.')[0]
        soma_z = row[3].split('.')[0]
        print(cell_id,soma_x,soma_y,soma_z)
        # 更新数据库表
        stmt = update(tracking_table).where(tracking_table.c['Cell ID'] == cell_id).values(soma_x=soma_x, soma_y=soma_y, soma_z=soma_z)
        session.execute(stmt)

# 提交事务
session.commit()

# 关闭Session
session.close()

print("数据库更新完成。")

