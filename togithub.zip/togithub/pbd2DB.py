import os

from sqlalchemy import create_engine, MetaData, Table, update
from sqlalchemy.orm import sessionmaker



def list_files_in_two_levels(root_dir):
    # 定义数据库URL
    SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"

    # 创建数据库引擎
    engineg = create_engine(SQLALCHEMY_DATABASE_URLg)

    # 创建MetaData对象
    metadatag = MetaData()

    # 反射目标表
    tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)

    # 创建会话
    Session = sessionmaker(bind=engineg)
    session = Session()
    #
    # ▒~A~M▒~N~F第▒~@▒~B▒~[▒▒~U
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # ▒~N▒▒~O~V▒~S▒~I~M▒~[▒▒~U▒~Z~D▒~B级
        level = dirpath.count(os.sep) - root_dir.count(os.sep)

        # ▒~B▒~^~\▒~X▒第▒~@▒~B▒~H~V第▒~L▒~B▒~[▒▒~U▒~L▒~S▒~G▒▒~V~G件▒~P~M
        if level < 2:
            for filename in filenames:
                # print(os.path.join(dirpath, filename))
                pbd=os.path.join(dirpath, filename)
                id=os.path.basename(pbd).split('_')[0]
                file_name = os.path.basename(pbd)
                # 获取文件路径（去掉最后的文件名）
                path_without_file = os.path.dirname(pbd)
                # 获取相对于 V3DPBD 的路径
                relative_path = os.path.relpath(path_without_file, start=os.path.dirname(path_without_file).rsplit("/", 2)[0] + "/V3DPBD")
                # 拼接相对路径和文件名
                DB = os.path.join("V3DPBD", relative_path, file_name)
                print(id,DB)
                # 更新swc_file列的第10到第12行

                stmt = (
                        update(tracking_table)
                        .where(tracking_table.c['Image Cell ID'] == id)  # 这里假设表中有一个主键id列
                        .values(v3dpbd_file=DB)
                )
                session.execute(stmt)
        # 提交事务
    session.commit()
    # 关闭会话
    session.close()






# 使▒~T▒示▒~Ky =
root_directory = '/mnt/nfs/hndb/V3DPBD/16000_16999'  # 请▒~[▒▒~M▒为▒| ▒~C▒▒~A▒~A~M▒~N~F▒~Z~D▒~V~G件夹路▒~D
list_files_in_two_levels(root_directory)

