import os

# rawfile="C:/Users/86132/Desktop/14011_P077_T01_(2)_S005_4hAFTsur_FL_TL.L_R0613_RJ_20240511_OMZ.v3draw"
# newrawfile_dir=os.path.dirname(rawfile)
# newrawfile_name=os.path.basename(rawfile)
# print(newrawfile_name)
# print(newrawfile_dir)

from sqlalchemy import create_engine, MetaData, Table, update
from sqlalchemy.orm import sessionmaker


def find_storage_path(base_folder, filename):
    file_number = int(filename.split('_')[0])  # 例如 "00028.txt" -> 28

    # 遍历基础文件夹，寻找合适的外层文件夹
    for outer_folder in os.listdir(base_folder):
        outer_folder_path = os.path.join(base_folder, outer_folder)
        if os.path.isdir(outer_folder_path):
            # 获取外层文件夹的范围
            outer_start, outer_end = map(int, outer_folder.split('_'))
            if outer_start <= file_number <= outer_end:
                # 遍历找到的外层文件夹，寻找合适的内层文件夹
                for inner_folder in os.listdir(outer_folder_path):
                    # print(outer_folder_path.split("\\")[-1])
                    f1=outer_folder_path.split("\\")[-1]
                    inner_folder_path = os.path.join(outer_folder_path, inner_folder)
                    if os.path.isdir(inner_folder_path):
                        # 获取内层文件夹的范围
                        inner_start, inner_end = map(int, inner_folder.split('_'))
                        if inner_start <= file_number <= inner_end:
                            f2=inner_folder_path.split("\\")[-1]
                            # 构造最终路径
                            # return os.path.join(inner_folder_path, filename)
                            return f1+"/"+f2

    return None  # 如果没有找到合适的文件夹

def get_swc_paths(folder):
    swcbasepath="/mnt/nfs/hndb/SWC/auto1.4"
    # 定义数据库URL
    SQLALCHEMY_DATABASE_URLg = "mysql+pymysql://root:hneuronbyseu123@localhost/human_neuron"
    # 创建数据库引擎
    engineg = create_engine(SQLALCHEMY_DATABASE_URLg)
    # 创建MetaData对象
    metadatag = MetaData()
    # 反射目标表
    tracking_table = Table('human_singlecell_trackingtable_20240712', metadatag, autoload_with=engineg)
    # 创建会话
    Session = sessionmaker(bind=engineg)
    session = Session()
    #
    swc_paths = []
    for dirpath, dnames, fnames in os.walk(folder):
        for f in fnames:
            if f.endswith('.eswc') or f.endswith('.swc'):
                parts=find_storage_path(swcbasepath, f).split('//')
                realpath = parts[1].split('/')[-2] + '/' + parts[1].split('/')[-1]
                databasepath=os.path.join("/SWC/auto1.4",realpath).replace("\\","/")
                databasepath=os.path.join(databasepath,f).replace("\\","/")

                mvpath=os.path.join(swcbasepath,realpath).replace("\\","/")
                cmd = f"mv /mnt/nfs/hndb/SWC_auto1.4/00001_10882/'{f}' '{mvpath}'"
                os.system(cmd)

                print(databasepath,"-----",mvpath)
                # 更新swc_file列的第10到第12行
                stmt = (
                    update(tracking_table)
                    .where(tracking_table.c['Cell ID'] == f.split("_")[0])  # 这里假设表中有一个主键id列
                    .values(swc_auto14=databasepath)
                )
                session.execute(stmt)
        # 提交事务
    session.commit()
    # 关闭会话
    session.close()

    return swc_paths

# 使用示例
folder_path = "/mnt/nfs/hndb/SWC_auto1.4/00001_10882"  # 替换为你的文件夹路径
A = get_swc_paths(folder_path)

